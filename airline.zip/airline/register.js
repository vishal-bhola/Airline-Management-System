var express = require('express');
var mysql = require('mysql');
var router=express.Router();
var cookieParser = require('cookie-parser');
var fs= require('fs');

const bodyParser = require('body-parser');
router.use(cookieParser());

//router.get('/:name', function(request, response){
//var flightno=request.params.name;
//response.end(flightno);
//console.log(flightno);
//response.end(flightno);
//});

router.get('/:name',function(req,res){
var flightno=req.params.name;
//response.end(flightno);
console.log(flightno);
//response.end(flightno);



console.log(req.body);

var connection = mysql.createConnection({
host:'localhost',
user:'root',
password: 'vishal',
database: 'airline'
});

connection.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");

});



//var flightno = req.body.flightno;
//console.log(flightno);

console.log("Register Here");


var sql = "select * from flight where flightno=?"
connection.query(sql,[flightno],function(err,result){
if(err) throw err;
else
{
console.log("Here you go");
console.log(result);
}

     res.writeHead(200, {
   'Content-Type': 'text/html'});


if(result.length>0)
{
res.write("<form action='/invoice' method='post'>")
res.write("<input type='text' name= 'flightno' style='setEditable:false;' value="+result[0].flightno+" readonly>");
res.write('<br>')
res.write("<input type='text' name= 'flightname' style='setEditable:false;' value="+result[0].flightname+" readonly>");

fs.readFile("Flighty/register.html",function(err,content)
  { res.end(content)});


//res.write("</form>");
}

//fs.readFile("Flighty/register.html",function(err,content)
 // { res.end(content)});

//res.end();

connection.end();

});

});


module.exports = router;
