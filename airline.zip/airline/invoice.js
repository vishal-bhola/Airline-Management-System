var express = require('express');
var mysql = require('mysql');
var router = express.Router();
var cookieParser = require('cookie-parser');
var fs = require('fs');

var bodyParser = require('body-parser');
router.use(cookieParser());



router.post('/',function(req,res)
{
console.log(req.body);
console.log('Hey Booked');


var desg= req.body.desg;
var flightno = req.body.flightno;
var flightname= req.body.flightname;
var firstname= req.body.fname;
var lastname = req.body.lname;
var phone = req.body.phno;
var number = req.body.no;
var email = req.body.email;
var type= req.body.type;

var connection = mysql.createConnection({
host:'localhost',
user:'root',
password: 'vishal',
database: 'airline'
});


//     res.writeHead(200, {
 //  'Content-Type': 'text/html'});


var date = new Date();

connection.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
 });

var data1;
var data2;

   var sql = "insert into booking values('"+flightno+"','"+flightname+"','"+desg+"','"+firstname+"','"+lastname+"','"+phone+"','"+number+"','"+email+"','"+type+"')";
   connection.query(sql,function(err,result){
        if (err) throw err;
	console.log('1 booking occured');

});

         var sql1="select * from booking where email = ? and fname = ? and lname =? and phno = ? and flightno = ? and flightname = ? and type=?";
        connection.query(sql1,[email,firstname,lastname,phone,flightno,flightname,type], function(err,result1){
       if(err) throw err;

                console.log(result1[0]);
                console.log(flightno);

              data1={fname:result1[0].fname,lname: result1[0].lname,email:result1[0].email,phno:result1[0].phno,number: result1[0].number,type: result1[0].type };
       //       res.render('invoice',{data});

                   console.log(data1);
});



var invoice = Math.floor(Math.random() * (110000 - 100000) +100000 );
var seatno =Math.floor(Math.random()*100);

       if(type=='Economy')
{
           var sql2 = "select * from flight where flightno=? and flightname =?";
                connection.query(sql2,[flightno,flightname],function(err,result2){
                if(err) throw err;

                 console.log(result2[0]);
              data2={flightno: result2[0].flightno,flightname: result2[0].flightname,startpoint: result2[0].startpoint,destpoint:result2[0].destpoint,arrivaltime: result2[0].arrivaltime,depttime: result2[0].depttime,fname:data1.fname,lname: data1.lname,email:data1.email,phno:data1.phno, number:data1.number,type:data1.type,fare:result2[0].economicfare,seatno:seatno,grandtotal: number*result2[0].economicfare,date:date,invoice:invoice};
                console.log(data2);

res.render('invoice',{data2});

});
}
else
{

 var sql2 = "select * from flight where flightno=? and flightname =?";
                connection.query(sql2,[flightno,flightname],function(err,result2){
                if(err) throw err;

                 console.log(result2[0]);
              data2={flightno: result2[0].flightno,flightname: result2[0].flightname,startpoint: result2[0].startpoint,destpoint:result2[0].destpoint,arrivaltime: result2[0].arrivaltime,depttime: result2[0].depttime,fname:data1.fname,lname: data1.lname,email:data1.email,phno:data1.phno, number:data1.number,type:data1.type,fare : result2[0].businessfare,seatno:seatno,grandtotal:number*result2[0].businessfare,date:date,invoice:invoice };
                console.log(data2);

res.render('invoice',{data2});
});

}

 // });

            //var data={fname:result[0].fname}; 

           // res.render('invoice',{data2});

//	});
 






//     res.writeHead(200, {
//   'Content-Type': 'text/html'});




//fs.readFile("./Flighty/invoice.html",function(err,content)
//  { res.end(content)});

//res.write('<table>');
//res.write('<tr><th>'+'Here You go'+'</th></tr>');
//res.write('<tr><th>'+firstname+'</th></tr>');
//res.write('<tr><th>'+flightno+'</th></tr>');
//res.write('</table>');


//Cres.render('invoice',{data});

connection.end();
});



module.exports=router;
